-- Prepared by: Jitendra Chauhan · SQL Server -> Snowflake migration · RBAC (DEV account)
-- =====================================================================
-- 07_guardrails.sql
-- Rule: nobody runs USE ROLE SECURITYADMIN / USERADMIN / SYSADMIN.
-- Project work uses NPDM_SECURITY_ADMIN and NPDM_ADMIN; ACCOUNTADMIN only
-- for account-level tasks.
-- Snowflake cannot block an ACCOUNTADMIN holder from switching to the
-- system roles, so this file checks for it instead.
-- ACCOUNT_USAGE views lag by up to ~45 minutes (QUERY_HISTORY) / ~2 hours (LOGIN_HISTORY).
-- =====================================================================
USE ROLE NPDM_SECURITY_ADMIN;
USE WAREHOUSE DEV_ENG_WH;

-- 1. Any work done under the system roles in the last 7 days (expect: no rows)
SELECT start_time, user_name, role_name, query_type,
       LEFT(query_text, 200) AS query_text
FROM   SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
WHERE  role_name IN ('SECURITYADMIN', 'USERADMIN', 'SYSADMIN')
  AND  start_time >= DATEADD(day, -7, CURRENT_TIMESTAMP())
ORDER BY start_time DESC;

-- 2. ACCOUNTADMIN use in the last 7 days (expect: bootstrap, monitors, account settings only)
SELECT start_time, user_name, query_type, LEFT(query_text, 200) AS query_text
FROM   SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
WHERE  role_name = 'ACCOUNTADMIN'
  AND  start_time >= DATEADD(day, -7, CURRENT_TIMESTAMP())
ORDER BY start_time DESC;

-- 3. Users holding system roles directly (expect: ACCOUNTADMIN for 2-3 named admins only)
SELECT grantee_name AS user_name, role, granted_by, created_on
FROM   SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_USERS
WHERE  role IN ('ACCOUNTADMIN', 'SECURITYADMIN', 'USERADMIN', 'SYSADMIN')
  AND  deleted_on IS NULL
ORDER BY role, user_name;

-- 4. Optional weekly e-mail alert (needs an e-mail notification integration,
--    created once by ACCOUNTADMIN; recipients must be verified Snowflake users)
-- USE ROLE ACCOUNTADMIN;
-- CREATE NOTIFICATION INTEGRATION IF NOT EXISTS NI_NPDM_EMAIL
--   TYPE = EMAIL ENABLED = TRUE ALLOWED_RECIPIENTS = ('<you@client.com>');
-- GRANT USAGE ON INTEGRATION NI_NPDM_EMAIL TO ROLE NPDM_SECURITY_ADMIN;
-- GRANT EXECUTE ALERT ON ACCOUNT TO ROLE NPDM_SECURITY_ADMIN;
-- USE ROLE NPDM_ADMIN;
-- GRANT USAGE, CREATE ALERT ON SCHEMA SF_NPDM.MIGRATION_CONTROL TO ROLE NPDM_SECURITY_ADMIN;
-- USE ROLE NPDM_SECURITY_ADMIN;
-- CREATE ALERT IF NOT EXISTS SF_NPDM.MIGRATION_CONTROL.ALERT_SYSTEM_ROLE_USE
--   WAREHOUSE = DEV_ENG_WH
--   SCHEDULE = 'USING CRON 0 9 * * MON Asia/Kolkata'
--   IF (EXISTS (
--       SELECT 1 FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
--       WHERE role_name IN ('SECURITYADMIN', 'USERADMIN', 'SYSADMIN')
--         AND start_time >= DATEADD(day, -7, CURRENT_TIMESTAMP())))
--   THEN CALL SYSTEM$SEND_EMAIL('NI_NPDM_EMAIL', '<you@client.com>',
--        'Snowflake DEV: system role used',
--        'SECURITYADMIN, USERADMIN or SYSADMIN was used in the last 7 days. Run 07_guardrails.sql, query 1.');
-- ALTER ALERT SF_NPDM.MIGRATION_CONTROL.ALERT_SYSTEM_ROLE_USE RESUME;
