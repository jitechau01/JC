-- Prepared by: Jitendra Chauhan · SQL Server -> Snowflake migration · RBAC (DEV account)
-- =====================================================================
-- 04_resource_monitors.sql
-- Run as ACCOUNTADMIN (only ACCOUNTADMIN can create resource monitors).
-- Quotas are starting points; adjust after the pilot measures real usage.
-- NOTIFY_USERS must be users with a verified email address.
-- =====================================================================
USE ROLE ACCOUNTADMIN;

-- whole account: alerts, then a hard stop (DEV only; PROD will not hard-stop)
CREATE RESOURCE MONITOR IF NOT EXISTS RM_DEV_ACCOUNT WITH
  CREDIT_QUOTA = 300
  FREQUENCY = MONTHLY
  START_TIMESTAMP = IMMEDIATELY
  TRIGGERS ON 50 PERCENT DO NOTIFY
           ON 75 PERCENT DO NOTIFY
           ON 90 PERCENT DO NOTIFY
           ON 100 PERCENT DO SUSPEND;
ALTER ACCOUNT SET RESOURCE_MONITOR = RM_DEV_ACCOUNT;

-- engineering warehouse
CREATE RESOURCE MONITOR IF NOT EXISTS RM_DEV_ENG_WH WITH
  CREDIT_QUOTA = 150
  FREQUENCY = MONTHLY
  START_TIMESTAMP = IMMEDIATELY
  NOTIFY_USERS = ("<YOUR_SNOWFLAKE_USER>")
  TRIGGERS ON 80 PERCENT DO NOTIFY
           ON 100 PERCENT DO SUSPEND
           ON 110 PERCENT DO SUSPEND_IMMEDIATE;
ALTER WAREHOUSE DEV_ENG_WH SET RESOURCE_MONITOR = RM_DEV_ENG_WH;

-- load warehouse (raise the quota for the month of the performance test)
CREATE RESOURCE MONITOR IF NOT EXISTS RM_DEV_LOAD_WH WITH
  CREDIT_QUOTA = 100
  FREQUENCY = MONTHLY
  START_TIMESTAMP = IMMEDIATELY
  NOTIFY_USERS = ("<YOUR_SNOWFLAKE_USER>")
  TRIGGERS ON 80 PERCENT DO NOTIFY
           ON 100 PERCENT DO SUSPEND;
ALTER WAREHOUSE DEV_LOAD_WH SET RESOURCE_MONITOR = RM_DEV_LOAD_WH;
