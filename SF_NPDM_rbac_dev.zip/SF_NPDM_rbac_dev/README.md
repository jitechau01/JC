Prepared by: Jitendra Chauhan · SQL Server → Snowflake migration · RBAC

# Snowflake RBAC scripts · SF_NPDM · DEV account

Matches the role catalogue (SF_NPDM_DEV_Role_Catalogue.xlsx) and the role diagram (SF_NPDM_Role_Hierarchy_DEV.drawio).
PROD is created later from the same scripts with the `PRD_` prefix, after the DEV pilot is signed off.

## What gets created

| Kind | Name | Purpose |
|---|---|---|
| Admin role | NPDM_ADMIN | Project admin (you): owns databases, warehouses, stage. Used instead of SYSADMIN |
| Admin role | NPDM_SECURITY_ADMIN | Project security admin (you): users, roles, grants. Used instead of SECURITYADMIN / USERADMIN |
| Functional role | DEV_DATA_ENGINEER | Engineers build, run, fix and validate the migration |
| Service role | DEV_CICD_DEPLOYER | CI/CD pipeline creates schemas, tables and framework objects |
| Service role | DEV_MIGRATION_LOADER | Migration framework uploads files and loads data |
| Database roles | SF_NPDM.READER / WRITER / OBJECT_OWNER | Access inside SF_NPDM (all schemas) |
| Database | SF_NPDM — one database per environment | Schemas: FOODSERVICES (one per source database), MIGRATION_CONTROL (control tables, logs, reconciliation), MIGRATION_STAGING (stage, file format) |
| Warehouses | DEV_ENG_WH, DEV_LOAD_WH | X-Small, auto-suspend 60 s |
| Service users | SVC_DEV_DEPLOY, SVC_DEV_MIGRATION | Key-pair only |
| Resource monitors | RM_DEV_ACCOUNT, RM_DEV_ENG_WH, RM_DEV_LOAD_WH | Cost guardrails |

## Run order

| # | File | Run as | Notes |
|---|---|---|---|
| 1 | 01_admin_bootstrap.sql | ACCOUNTADMIN | Creates NPDM_SECURITY_ADMIN and NPDM_ADMIN, gives you both, network policy |
| 2 | 02_dev_objects_and_roles.sql | switches roles inside | Databases, FOODSERVICES schema, stage, database roles, warehouses, roles, service users |
| 3 | 03_people.sql | NPDM_SECURITY_ADMIN | Engineers (skip user creation if SCIM is used) |
| 4 | 04_resource_monitors.sql | ACCOUNTADMIN | Cost guardrails |
| 5 | 05_schema_template.sql | DEV_CICD_DEPLOYER, then DEV_MIGRATION_LOADER | Pattern per source database: deploy DDL, then load |
| 6 | 99_verify.sql | NPDM_SECURITY_ADMIN, then each role | Inventory and must-succeed / must-fail tests |
| 7 | 07_guardrails.sql | NPDM_SECURITY_ADMIN | Weekly: any use of SECURITYADMIN / USERADMIN / SYSADMIN, ACCOUNTADMIN use, optional e-mail alert |
| — | 06_optional_roles.sql | — | Masking, sensitive schemas, SCIM, read-only reviewers, auditors. Run a section only when needed |

All files are safe to re-run.

## Before you run

1. Replace every `<placeholder>`: your Snowflake user, IP ranges, engineer emails, two public keys.
2. Generate one key pair per service user and keep the private keys in the client vault:

```bash
openssl genrsa 2048 | openssl pkcs8 -topk8 -inform PEM -out svc_dev_deploy_key.p8 -nocrypt
openssl rsa -in svc_dev_deploy_key.p8 -pubout -out svc_dev_deploy_key.pub
openssl genrsa 2048 | openssl pkcs8 -topk8 -inform PEM -out svc_dev_migration_key.p8 -nocrypt
openssl rsa -in svc_dev_migration_key.p8 -pubout -out svc_dev_migration_key.pub
```

   Paste each `.pub` file's contents, without the BEGIN/END lines, into `RSA_PUBLIC_KEY` in file 02.
   Use encrypted keys (drop `-nocrypt`) if the client's policy requires it.

## Your admin access

| Task | Role |
|---|---|
| Databases, schemas, warehouses, stage | `NPDM_ADMIN` (default role) |
| Users, roles, grants | `NPDM_SECURITY_ADMIN` |
| Account settings, resource monitors, network policy | `ACCOUNTADMIN` (granted by the client) |
| — | **Never** `USE ROLE SECURITYADMIN`, `USERADMIN` or `SYSADMIN` |

- SECURITYADMIN, USERADMIN and SYSADMIN are not granted to any user. They stay only as system parents of the project roles.
- ACCOUNTADMIN holders can still switch to them (Snowflake cannot block it), so `07_guardrails.sql` reports any use.
- Secondary roles are off for admins (`DEFAULT_SECONDARY_ROLES = ()`), so ACCOUNTADMIN is never active by accident.

## Who can do what

| Role | Source-data schemas (FOODSERVICES, …) | MIGRATION_CONTROL | Stage (MIGRATION_STAGING) | DEV_ENG_WH | DEV_LOAD_WH |
|---|---|---|---|---|---|
| NPDM_ADMIN | own | own | own | own | own |
| NPDM_SECURITY_ADMIN | grants only | grants only | grants only | use (audit queries) | — |
| DEV_DATA_ENGINEER | own | own | read / write | use | use |
| DEV_CICD_DEPLOYER | own (create, alter, drop) | own | read / write | — | use |
| DEV_MIGRATION_LOADER | read / write (load, reload) | read / write | read / write | — | use |

Own = create, drop, load, read · read / write = change rows, no create or drop · use = run queries on the warehouse.
