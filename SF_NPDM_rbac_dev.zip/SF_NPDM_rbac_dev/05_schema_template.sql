-- Prepared by: Jitendra Chauhan · SQL Server -> Snowflake migration · RBAC (DEV account)
-- =====================================================================
-- 05_schema_template.sql
-- The pattern repeated for each source database.
--   Part A (DDL)  runs in the CI/CD pipeline as SVC_DEV_DEPLOY   (role DEV_CICD_DEPLOYER)
--   Part B (load) runs in the framework     as SVC_DEV_MIGRATION (role DEV_MIGRATION_LOADER)
-- Example: source database FoodServices -> schema SF_NPDM.FOODSERVICES
-- (already created by file 02; for it the CREATE SCHEMA is a no-op).
-- Table and columns are placeholders: the DDL generator writes the real
-- ones from SQL Server metadata.
-- =====================================================================

-- ---------- Part A · deployment (DEV_CICD_DEPLOYER) ------------------------
USE ROLE DEV_CICD_DEPLOYER;
USE WAREHOUSE DEV_LOAD_WH;

-- 1. one schema per source database, managed access
CREATE SCHEMA IF NOT EXISTS SF_NPDM.FOODSERVICES
  WITH MANAGED ACCESS
  DATA_RETENTION_TIME_IN_DAYS = 1
  COMMENT = 'Source: <INSTANCE>.FoodServices';

-- 2. hand a NEW schema to the database owner role, so access stays central
--    (skip for FOODSERVICES: file 02 already did this)
-- GRANT OWNERSHIP ON SCHEMA SF_NPDM.<NEW_SCHEMA>
--   TO DATABASE ROLE SF_NPDM.OBJECT_OWNER COPY CURRENT GRANTS;

-- 3. tables: dbo keeps its name, other source schemas become <SCHEMA>__<TABLE>
CREATE TABLE IF NOT EXISTS SF_NPDM.FOODSERVICES.MEAL_SERVICE (
    MEAL_SERVICE_ID  NUMBER(19,0) NOT NULL,
    FACILITY_ID      NUMBER(10,0),
    SERVICE_DATE     TIMESTAMP_NTZ(3),
    MEAL_TYPE        VARCHAR(20),
    DIET_CODE        CHAR(4),
    MEALS_SERVED     NUMBER(10,0),
    COST_AMOUNT      NUMBER(18,2),
    IS_ACTIVE        BOOLEAN
);
-- New tables are owned by SF_NPDM.OBJECT_OWNER (future ownership grant in file 02);
-- READER gets SELECT and WRITER gets INSERT/DELETE/TRUNCATE automatically.

-- ---------- Part B · load (DEV_MIGRATION_LOADER) ----------------------------
USE ROLE DEV_MIGRATION_LOADER;
USE WAREHOUSE DEV_LOAD_WH;
-- PUT file:///data/extract/foodservices/meal_service/*.parquet
--     @SF_NPDM.MIGRATION_STAGING.STG_HISTORY/foodservices/meal_service/ AUTO_COMPRESS = FALSE PARALLEL = 8;
-- COPY INTO SF_NPDM.FOODSERVICES.MEAL_SERVICE
--   FROM @SF_NPDM.MIGRATION_STAGING.STG_HISTORY/foodservices/meal_service/
--   FILE_FORMAT = (FORMAT_NAME = SF_NPDM.MIGRATION_STAGING.FF_PARQUET)
--   MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
--   ON_ERROR = ABORT_STATEMENT;
-- Rerun of a failed chunk: DELETE FROM ... WHERE <chunk range>; then COPY again.
