-- Prepared by: Jitendra Chauhan · SQL Server -> Snowflake migration · RBAC (DEV account)
-- =====================================================================
-- 99_verify.sql · run after files 01-05
-- Part 1 lists what exists. Part 2 tests that each role can do what it
-- should and nothing more: run the "must FAIL" lines one at a time.
-- =====================================================================

-- ---------- Part 1: inventory ------------------------------------------------
USE ROLE NPDM_SECURITY_ADMIN;
SHOW ROLES LIKE 'DEV_%';
SHOW ROLES LIKE 'NPDM_%';
SHOW GRANTS OF ROLE SECURITYADMIN;           -- expect roles only (ACCOUNTADMIN), no users
SHOW GRANTS OF ROLE USERADMIN;               -- expect roles only, no users
SHOW GRANTS TO ROLE NPDM_SECURITY_ADMIN;     -- expect CREATE USER, CREATE ROLE, MANAGE GRANTS
SHOW DATABASE ROLES IN DATABASE SF_NPDM;
SHOW FUTURE GRANTS IN DATABASE SF_NPDM;
SHOW GRANTS TO ROLE DEV_DATA_ENGINEER;
SHOW GRANTS TO ROLE DEV_CICD_DEPLOYER;
SHOW GRANTS TO ROLE DEV_MIGRATION_LOADER;
SHOW GRANTS TO DATABASE ROLE SF_NPDM.WRITER;
SHOW GRANTS OF ROLE DEV_CICD_DEPLOYER;        -- expect SVC_DEV_DEPLOY and SYSADMIN only
SHOW GRANTS OF ROLE DEV_MIGRATION_LOADER;     -- expect SVC_DEV_MIGRATION and SYSADMIN only
SHOW GRANTS TO ROLE PUBLIC;                   -- expect nothing added by this project

-- ---------- Part 2: functional tests -------------------------------------------
-- (needs the MEAL_SERVICE table from 05_schema_template.sql, Part A)

-- Deployer: creates and drops objects
USE ROLE DEV_CICD_DEPLOYER;  USE WAREHOUSE DEV_LOAD_WH;
CREATE SCHEMA IF NOT EXISTS SF_NPDM.ZZ_RBAC_TEST;             -- succeeds
DROP SCHEMA IF EXISTS SF_NPDM.ZZ_RBAC_TEST;                   -- succeeds

-- Loader: loads data and uses the stage, cannot create or drop
USE ROLE DEV_MIGRATION_LOADER;  USE WAREHOUSE DEV_LOAD_WH;
LIST @SF_NPDM.MIGRATION_STAGING.STG_HISTORY;                  -- succeeds
SELECT COUNT(*) FROM SF_NPDM.FOODSERVICES.MEAL_SERVICE;       -- succeeds
DELETE FROM SF_NPDM.FOODSERVICES.MEAL_SERVICE WHERE 1 = 0;    -- succeeds (deletes nothing)
-- CREATE SCHEMA SF_NPDM.ZZ_LOADER_TEST;                      -- must FAIL (not an owner)
-- DROP TABLE SF_NPDM.FOODSERVICES.MEAL_SERVICE;              -- must FAIL (not an owner)
-- USE WAREHOUSE DEV_ENG_WH;                                  -- must FAIL (no usage)

-- Engineer: full control in DEV, including validation queries
USE ROLE DEV_DATA_ENGINEER;  USE WAREHOUSE DEV_ENG_WH;
SELECT COUNT(*) FROM SF_NPDM.FOODSERVICES.MEAL_SERVICE;       -- succeeds
CREATE SCHEMA IF NOT EXISTS SF_NPDM.ZZ_ENG_TEST;              -- succeeds
DROP SCHEMA IF EXISTS SF_NPDM.ZZ_ENG_TEST;                    -- succeeds
