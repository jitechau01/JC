-- Prepared by: Jitendra Chauhan · SQL Server -> Snowflake migration · RBAC (DEV account)
-- =====================================================================
-- 03_people.sql
-- Creates team members and gives each ONE role.
-- Use this when users are created by hand. If the client switches on
-- Entra ID SCIM (06_optional_roles.sql, section C), skip CREATE USER and
-- map Entra ID groups to roles instead.
-- =====================================================================

-- ---------- 1. Users -------------------------------------------------------
-- With Entra ID SSO, people sign in through Entra ID; no password is set here.
-- Without SSO, set a temporary password and MUST_CHANGE_PASSWORD = TRUE;
-- Snowflake requires MFA for password sign-in by people.
USE ROLE NPDM_SECURITY_ADMIN;

CREATE USER IF NOT EXISTS "<ENGINEER1@CLIENT.COM>"
  TYPE = PERSON
  LOGIN_NAME = '<ENGINEER1@CLIENT.COM>'
  EMAIL = '<ENGINEER1@CLIENT.COM>'
  DISPLAY_NAME = '<Engineer 1>'
  DEFAULT_ROLE = DEV_DATA_ENGINEER
  DEFAULT_WAREHOUSE = DEV_ENG_WH
  DEFAULT_SECONDARY_ROLES = ('ALL')
  COMMENT = 'Data engineer: builds, runs, fixes and validates the migration';

-- copy the block above for each engineer

-- ---------- 2. Role assignments --------------------------------------------
USE ROLE NPDM_SECURITY_ADMIN;
GRANT ROLE DEV_DATA_ENGINEER TO USER "<ENGINEER1@CLIENT.COM>";
-- GRANT ROLE DEV_DATA_ENGINEER TO USER "<ENGINEER2@CLIENT.COM>";
-- GRANT ROLE DEV_DATA_ENGINEER TO USER "<ENGINEER3@CLIENT.COM>";
-- GRANT ROLE DEV_DATA_ENGINEER TO USER "<ARCHITECT@CLIENT.COM>";
-- A second admin, if the client wants a backup for you:
-- GRANT ROLE NPDM_ADMIN TO USER "<SECOND_ADMIN@CLIENT.COM>";

-- ---------- 3. Leavers --------------------------------------------------------
-- ALTER USER "<LEAVER@CLIENT.COM>" SET DISABLED = TRUE;
-- REVOKE ROLE DEV_DATA_ENGINEER FROM USER "<LEAVER@CLIENT.COM>";
