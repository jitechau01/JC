-- Prepared by: Jitendra Chauhan · SQL Server -> Snowflake migration · RBAC (DEV account)
-- =====================================================================
-- 02_dev_objects_and_roles.sql
-- Run after 01_admin_bootstrap.sql. Switches role inside; you need
-- NPDM_ADMIN and NPDM_SECURITY_ADMIN (granted in file 01).
-- Safe to re-run: everything uses IF NOT EXISTS or idempotent GRANTs.
--
-- Creates:  1 database SF_NPDM with schemas
--             FOODSERVICES        (migrated data; one schema per source database)
--             MIGRATION_CONTROL   (control tables, run log, reconciliation)
--             MIGRATION_STAGING   (stage and file format)
--           3 database roles · 2 warehouses
--           1 functional role · 2 service roles · 2 service users
-- =====================================================================

-- ---------- 1. Database --------------------------------------------------
USE ROLE NPDM_ADMIN;
CREATE DATABASE IF NOT EXISTS SF_NPDM
  DATA_RETENTION_TIME_IN_DAYS = 1
  COMMENT = 'NPDM data in Snowflake: one schema per SQL Server source database, plus MIGRATION_* framework schemas.';

-- NPDM_SECURITY_ADMIN needs USAGE on the database to manage future grants for its database roles
GRANT USAGE ON DATABASE SF_NPDM TO ROLE NPDM_SECURITY_ADMIN;

-- ---------- 2. Database roles (access layer) ------------------------------
-- OBJECT_OWNER  contains  WRITER  contains  READER
CREATE DATABASE ROLE IF NOT EXISTS SF_NPDM.READER        COMMENT = 'Read all tables and views in SF_NPDM';
CREATE DATABASE ROLE IF NOT EXISTS SF_NPDM.WRITER        COMMENT = 'Load and reload data, write control tables, use the stage (includes READER)';
CREATE DATABASE ROLE IF NOT EXISTS SF_NPDM.OBJECT_OWNER  COMMENT = 'Create, alter, drop and own schemas and tables (includes WRITER)';

GRANT DATABASE ROLE SF_NPDM.READER TO DATABASE ROLE SF_NPDM.WRITER;
GRANT DATABASE ROLE SF_NPDM.WRITER TO DATABASE ROLE SF_NPDM.OBJECT_OWNER;

-- the project admin holds the owner role
GRANT DATABASE ROLE SF_NPDM.OBJECT_OWNER TO ROLE NPDM_ADMIN;

-- ---------- 3. Future grants (every new schema and table is covered) ------
USE ROLE NPDM_SECURITY_ADMIN;   -- MANAGE GRANTS is needed for database-level future grants
GRANT USAGE ON DATABASE SF_NPDM TO DATABASE ROLE SF_NPDM.READER;
GRANT USAGE  ON FUTURE SCHEMAS IN DATABASE SF_NPDM TO DATABASE ROLE SF_NPDM.READER;
GRANT SELECT ON FUTURE TABLES  IN DATABASE SF_NPDM TO DATABASE ROLE SF_NPDM.READER;
GRANT SELECT ON FUTURE VIEWS   IN DATABASE SF_NPDM TO DATABASE ROLE SF_NPDM.READER;
GRANT INSERT, UPDATE, DELETE, TRUNCATE ON FUTURE TABLES IN DATABASE SF_NPDM TO DATABASE ROLE SF_NPDM.WRITER;
GRANT CREATE SCHEMA ON DATABASE SF_NPDM TO DATABASE ROLE SF_NPDM.OBJECT_OWNER;
GRANT OWNERSHIP ON FUTURE TABLES IN DATABASE SF_NPDM TO DATABASE ROLE SF_NPDM.OBJECT_OWNER;

-- If any schemas or tables were created BEFORE the future grants above, catch them up:
-- GRANT USAGE  ON ALL SCHEMAS IN DATABASE SF_NPDM TO DATABASE ROLE SF_NPDM.READER;
-- GRANT SELECT ON ALL TABLES  IN DATABASE SF_NPDM TO DATABASE ROLE SF_NPDM.READER;
-- GRANT INSERT, UPDATE, DELETE, TRUNCATE ON ALL TABLES IN DATABASE SF_NPDM TO DATABASE ROLE SF_NPDM.WRITER;

-- ---------- 4. Schemas -----------------------------------------------------
-- Created after the future grants, so READER / WRITER / OBJECT_OWNER cover them
-- automatically. Each is then handed to the database owner role.
-- Further source databases follow 05_schema_template.sql.
USE ROLE NPDM_ADMIN;
CREATE SCHEMA IF NOT EXISTS SF_NPDM.FOODSERVICES
  WITH MANAGED ACCESS DATA_RETENTION_TIME_IN_DAYS = 1
  COMMENT = 'Source: <INSTANCE>.FoodServices';
CREATE SCHEMA IF NOT EXISTS SF_NPDM.MIGRATION_CONTROL
  WITH MANAGED ACCESS DATA_RETENTION_TIME_IN_DAYS = 1
  COMMENT = 'Migration framework: control tables, run log, reconciliation results';
CREATE SCHEMA IF NOT EXISTS SF_NPDM.MIGRATION_STAGING
  WITH MANAGED ACCESS DATA_RETENTION_TIME_IN_DAYS = 1
  COMMENT = 'Migration framework: internal stage and file formats';

-- ---------- 5. Stage and file format ---------------------------------------
CREATE FILE FORMAT IF NOT EXISTS SF_NPDM.MIGRATION_STAGING.FF_PARQUET
  TYPE = PARQUET
  COMMENT = 'History extract files';
CREATE STAGE IF NOT EXISTS SF_NPDM.MIGRATION_STAGING.STG_HISTORY
  FILE_FORMAT = SF_NPDM.MIGRATION_STAGING.FF_PARQUET
  COMMENT = 'Parquet files land here; emptied after each table passes reconciliation';

-- hand the schemas to the database owner role, so access stays central
GRANT OWNERSHIP ON SCHEMA SF_NPDM.FOODSERVICES      TO DATABASE ROLE SF_NPDM.OBJECT_OWNER COPY CURRENT GRANTS;
GRANT OWNERSHIP ON SCHEMA SF_NPDM.MIGRATION_CONTROL TO DATABASE ROLE SF_NPDM.OBJECT_OWNER COPY CURRENT GRANTS;
GRANT OWNERSHIP ON SCHEMA SF_NPDM.MIGRATION_STAGING TO DATABASE ROLE SF_NPDM.OBJECT_OWNER COPY CURRENT GRANTS;

USE ROLE NPDM_SECURITY_ADMIN;
GRANT READ, WRITE ON STAGE SF_NPDM.MIGRATION_STAGING.STG_HISTORY TO DATABASE ROLE SF_NPDM.WRITER;
GRANT USAGE ON FILE FORMAT SF_NPDM.MIGRATION_STAGING.FF_PARQUET  TO DATABASE ROLE SF_NPDM.WRITER;

-- ---------- 6. Warehouses (granted directly to roles) ----------------------
USE ROLE NPDM_ADMIN;
CREATE WAREHOUSE IF NOT EXISTS DEV_ENG_WH
  WAREHOUSE_SIZE = XSMALL AUTO_SUSPEND = 60 AUTO_RESUME = TRUE INITIALLY_SUSPENDED = TRUE
  STATEMENT_TIMEOUT_IN_SECONDS = 3600 STATEMENT_QUEUED_TIMEOUT_IN_SECONDS = 900
  COMMENT = 'Engineering queries, testing and reconciliation';
CREATE WAREHOUSE IF NOT EXISTS DEV_LOAD_WH
  WAREHOUSE_SIZE = XSMALL AUTO_SUSPEND = 60 AUTO_RESUME = TRUE INITIALLY_SUSPENDED = TRUE
  STATEMENT_TIMEOUT_IN_SECONDS = 14400 STATEMENT_QUEUED_TIMEOUT_IN_SECONDS = 1800
  COMMENT = 'Deployments and COPY INTO loads. Resize to MEDIUM only for the pilot performance test.';

-- ---------- 7. Functional and service roles ---------------------------------
USE ROLE NPDM_SECURITY_ADMIN;
CREATE ROLE IF NOT EXISTS DEV_DATA_ENGINEER    COMMENT = 'Functional role: engineers build, run, fix and validate the migration in DEV';
CREATE ROLE IF NOT EXISTS DEV_CICD_DEPLOYER    COMMENT = 'Service role: CI/CD pipeline. Creates schemas, tables and framework objects from Git.';
CREATE ROLE IF NOT EXISTS DEV_MIGRATION_LOADER COMMENT = 'Service role: migration framework. Uploads files and loads data; cannot create or drop objects.';

GRANT DATABASE ROLE SF_NPDM.OBJECT_OWNER TO ROLE DEV_DATA_ENGINEER;     -- full control in DEV, incl. reconciliation
GRANT DATABASE ROLE SF_NPDM.OBJECT_OWNER TO ROLE DEV_CICD_DEPLOYER;     -- owns what it deploys
GRANT DATABASE ROLE SF_NPDM.WRITER       TO ROLE DEV_MIGRATION_LOADER;  -- loads data, writes control tables, uses the stage

-- every custom role rolls up to SYSADMIN
GRANT ROLE DEV_DATA_ENGINEER    TO ROLE SYSADMIN;
GRANT ROLE DEV_CICD_DEPLOYER    TO ROLE SYSADMIN;
GRANT ROLE DEV_MIGRATION_LOADER TO ROLE SYSADMIN;

-- warehouses (the owner, NPDM_ADMIN, grants usage)
USE ROLE NPDM_ADMIN;
GRANT USAGE ON WAREHOUSE DEV_ENG_WH  TO ROLE DEV_DATA_ENGINEER;
GRANT USAGE ON WAREHOUSE DEV_LOAD_WH TO ROLE DEV_DATA_ENGINEER;
GRANT USAGE ON WAREHOUSE DEV_LOAD_WH TO ROLE DEV_CICD_DEPLOYER;
GRANT USAGE ON WAREHOUSE DEV_LOAD_WH TO ROLE DEV_MIGRATION_LOADER;
GRANT USAGE ON WAREHOUSE DEV_ENG_WH  TO ROLE NPDM_SECURITY_ADMIN;   -- audit queries in 07_guardrails.sql

-- ---------- 8. Service users (key-pair only, no password, no MFA prompt) -----
-- Generate one key pair per service user first (see README).
USE ROLE NPDM_SECURITY_ADMIN;
CREATE USER IF NOT EXISTS SVC_DEV_DEPLOY
  TYPE = SERVICE
  DEFAULT_ROLE = DEV_CICD_DEPLOYER
  DEFAULT_WAREHOUSE = DEV_LOAD_WH
  DEFAULT_SECONDARY_ROLES = ()
  RSA_PUBLIC_KEY = '<deploy public key from the vault, without header/footer lines>'
  COMMENT = 'CI/CD pipeline (Git) deploying DDL';
CREATE USER IF NOT EXISTS SVC_DEV_MIGRATION
  TYPE = SERVICE
  DEFAULT_ROLE = DEV_MIGRATION_LOADER
  DEFAULT_WAREHOUSE = DEV_LOAD_WH
  DEFAULT_SECONDARY_ROLES = ()
  RSA_PUBLIC_KEY = '<migration public key from the vault, without header/footer lines>'
  COMMENT = 'Migration framework (Python) on the extract server';

GRANT ROLE DEV_CICD_DEPLOYER    TO USER SVC_DEV_DEPLOY;
GRANT ROLE DEV_MIGRATION_LOADER TO USER SVC_DEV_MIGRATION;

-- ---------- Note for PROD ----------------------------------------------------
-- READER also sees MIGRATION_CONTROL (row counts, logs). Harmless in DEV.
-- In PROD, after go-live, either drop the MIGRATION_* schemas or run:
-- REVOKE USAGE ON SCHEMA SF_NPDM.MIGRATION_CONTROL FROM DATABASE ROLE SF_NPDM.READER;
-- REVOKE USAGE ON SCHEMA SF_NPDM.MIGRATION_STAGING FROM DATABASE ROLE SF_NPDM.READER;
