-- Prepared by: Jitendra Chauhan · SQL Server -> Snowflake migration · RBAC (DEV account)
-- =====================================================================
-- 01_admin_bootstrap.sql
-- Run ONCE in the DEV account, as ACCOUNTADMIN.
-- Creates the two project admin roles and gives you admin access.
-- Rule from here on: nobody (admins included) runs USE ROLE SECURITYADMIN,
-- USE ROLE USERADMIN or USE ROLE SYSADMIN. Project work uses:
--   NPDM_SECURITY_ADMIN  -> users, roles, grants   (instead of SECURITYADMIN / USERADMIN)
--   NPDM_ADMIN           -> databases, warehouses, stage (instead of SYSADMIN)
-- Replace every <placeholder> before running.
-- =====================================================================
USE ROLE ACCOUNTADMIN;

-- ---------- 1. Project security admin --------------------------------------
-- Holds exactly the account privileges needed to manage users, roles and grants.
-- MANAGE GRANTS is required for database-level future grants and for granting
-- roles it does not own. Rolls up to SECURITYADMIN, so the system roles keep control.
CREATE ROLE IF NOT EXISTS NPDM_SECURITY_ADMIN
  COMMENT = 'Project security admin: creates users and roles, manages grants. Used instead of SECURITYADMIN / USERADMIN.';
GRANT CREATE USER   ON ACCOUNT TO ROLE NPDM_SECURITY_ADMIN;
GRANT CREATE ROLE   ON ACCOUNT TO ROLE NPDM_SECURITY_ADMIN;
GRANT MANAGE GRANTS ON ACCOUNT TO ROLE NPDM_SECURITY_ADMIN;
GRANT ROLE NPDM_SECURITY_ADMIN TO ROLE SECURITYADMIN;
-- read-only audit views, so the security admin can check who used which role (07_guardrails.sql)
GRANT DATABASE ROLE SNOWFLAKE.SECURITY_VIEWER   TO ROLE NPDM_SECURITY_ADMIN;
GRANT DATABASE ROLE SNOWFLAKE.GOVERNANCE_VIEWER TO ROLE NPDM_SECURITY_ADMIN;

-- ---------- 2. Project admin -----------------------------------------------
-- Created by NPDM_SECURITY_ADMIN, so the project security admin owns it.
USE ROLE NPDM_SECURITY_ADMIN;
CREATE ROLE IF NOT EXISTS NPDM_ADMIN
  COMMENT = 'Project admin: creates and owns databases, warehouses and the stage. Used instead of SYSADMIN.';
GRANT ROLE NPDM_ADMIN TO ROLE SYSADMIN;              -- every custom role rolls up to SYSADMIN

USE ROLE ACCOUNTADMIN;
GRANT CREATE DATABASE  ON ACCOUNT TO ROLE NPDM_ADMIN;
GRANT CREATE WAREHOUSE ON ACCOUNT TO ROLE NPDM_ADMIN;

-- ---------- 3. Your own admin access ---------------------------------------
-- You already hold ACCOUNTADMIN (granted by the client). You also get the two
-- project roles; SECURITYADMIN, USERADMIN and SYSADMIN are never granted to anyone.
USE ROLE NPDM_SECURITY_ADMIN;
GRANT ROLE NPDM_ADMIN          TO USER "<YOUR_SNOWFLAKE_USER>";
GRANT ROLE NPDM_SECURITY_ADMIN TO USER "<YOUR_SNOWFLAKE_USER>";
-- ACCOUNTADMIN is used only for: this bootstrap file, resource monitors
-- (04_resource_monitors.sql), network policy and account settings.

USE ROLE ACCOUNTADMIN;   -- changing another user's settings needs the user's owner or ACCOUNTADMIN
ALTER USER "<YOUR_SNOWFLAKE_USER>" SET
  DEFAULT_ROLE = NPDM_ADMIN
  DEFAULT_SECONDARY_ROLES = ();
-- Secondary roles stay OFF for admins: ('ALL') would silently activate
-- ACCOUNTADMIN in every session. Switch explicitly instead:
--   USE ROLE NPDM_ADMIN;            objects
--   USE ROLE NPDM_SECURITY_ADMIN;   users, roles, grants
--   USE ROLE ACCOUNTADMIN;          account settings and resource monitors only
-- Never set ACCOUNTADMIN as anyone's default role.

-- ---------- 4. Network policy (fill in the client's ranges) ----------------
CREATE NETWORK POLICY IF NOT EXISTS NP_DEV_ACCOUNT
  ALLOWED_IP_LIST = ('<office_cidr>', '<vpn_cidr>', '<extract_server_ip>')
  COMMENT = 'Office, VPN and extract server only';
-- Test on yourself first, from an allowed address:
-- ALTER USER "<YOUR_SNOWFLAKE_USER>" SET NETWORK_POLICY = NP_DEV_ACCOUNT;
-- Then switch it on for the whole account:
-- ALTER ACCOUNT SET NETWORK_POLICY = NP_DEV_ACCOUNT;

-- ---------- 5. Hygiene -----------------------------------------------------
-- SECURITYADMIN, USERADMIN, SYSADMIN: no users granted directly, and nobody
-- switches to them. They stay only as system parents of the project roles.
-- ACCOUNTADMIN holders CAN still switch to them (Snowflake cannot block this),
-- so 07_guardrails.sql reports any such use.
-- ACCOUNTADMIN: 2-3 named people, MFA, never a default role, never used by scripts.
-- Nothing is granted to PUBLIC in this project.
